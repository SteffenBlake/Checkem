# Checkem
Simple Trust Checker for FFXI, requires EliteAPI.dll and EliteMMO.API.dll

Download here: http://www.elitemmonetwork.com/forums/viewtopic.php?f=28&t=82
